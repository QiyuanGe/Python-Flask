#coding:utf8
DATABASE = 'user.db'      
DEBUG = True                  
SECRET_KEY = 'secret_key_1'   
