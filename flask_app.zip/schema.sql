CREATE TABLE task (
  User_ID INTEGER,
  Side_number INTEGER,
  Task_name TEXT,
  Activite_time TIME,
  Activity_type TEXT,
  Sum_time TIME,
  FOREIGN KEY (User_ID) REFERENCES Userinfomation (User_ID)
);
